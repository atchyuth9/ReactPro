import React, { Fragment } from "react";

class Wishcard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      message: "hello"
    };
  }
  updateMessage = () => {
    this.setState({
      message: "good mrg"
    });
  };
  sayHi = (value) => {
    this.setState({
      message: value
    });
  };

  render() {
    return (
      <Fragment>
        <div>
          <h2> {this.state.message}</h2>
          <button onClick={this.updateMessage} className="click">
            GoodMorning
          </button>
          <button
            onClick={this.sayHi.bind(this, "heyman")}
            className="passdata"
          >
            gooodbye
          </button>
        </div>
      </Fragment>
    );
  }
}
export default Wishcard;
