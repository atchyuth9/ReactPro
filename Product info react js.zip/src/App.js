import React, { Fragment } from "react";
import ReactDOM from "react-dom";
import Greetingcard from "./Greetingcard";
import Greetingmsg2 from "./Greetingmsg2";
import ProductItem from "./ProductItem";
import styles from "./styles.css";
import Wishcard from "./Wishcard";
let App = () => {
  return (
    <Fragment>
      <nav className="nav">
        <a href="/">Ajio Shopping</a>
      </nav>
      {/* <Wishcard />*/}
      {/*<Greetingcard />*/}
      {/*} <Greetingmsg2 />*/}
      <ProductItem />
    </Fragment>
  );
};

export default App;
